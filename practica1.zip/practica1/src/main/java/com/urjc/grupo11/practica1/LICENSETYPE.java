package com.urjc.grupo11.practica1;

public enum LICENSETYPE {
        PERSONAL,
        COMMERCIAL
}
