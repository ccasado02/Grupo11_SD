package com.urjc.grupo11.practica1;

public enum GENERO {
    POP, TRAP, RAP, HIP_HOP, RB, REGGAETON, ELECTRONICA
}
