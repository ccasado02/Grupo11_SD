package com.urjc.grupo11.practica1;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicLong;
import org.springframework.stereotype.Service;

@Service
public class BeatService {
    private ConcurrentMap<Long, Beat> beats = new ConcurrentHashMap<>();
    private AtomicLong nextId = new AtomicLong(1);

    public BeatService(){
        // TRAP
        save(new Beat("TTRRAP 56", GENERO.TRAP, "Beat de trap tipo freestyle", "O0YBgFXqoKk", 15.99, new HashSet<>(Arrays.asList("trap", "trrap56","56", "freestyle", "trap", "enérgico")), 3));
        save(new Beat("TTRRAP 55", GENERO.TRAP, "Beat de trap estilo freestyle", "hmGMUg8JV6-M", 13.99, new HashSet<>(Arrays.asList("trap", "trrap55", "55", "trrap", "freestyle", "enérgico")),3));
        save(new Beat("QUE TENGO QUE HACER", GENERO.TRAP, "Beat de trap tipo Bad Bunny y Anuel", "xvw2T2r2qbU", 6.66, new HashSet<>(Arrays.asList("trap", "Bunny", "Bad", "la doble","AA", "badbo", "conejo", "2016", "enfadado", "energico")), 3));
        save(new Beat("BLOQUE", GENERO.TRAP, "Beat de trap tipo Myke Towers y Eladio Carrion", "JhXLLgVcHI0", 19.99, new HashSet<>(Arrays.asList("trap", "calle", "bloque", "myke","eladio", "towers","easy", "money", "sendo", "energico", "enfadado")), 3));
        // REGGAETON
        save(new Beat("LOCURAS", GENERO.REGGAETON, "Beat de reggaeton tipo Jhay Cortez", "9YRfoMccgh0", 8.99, new HashSet<>(Arrays.asList("reggaeton","locuras", "jhay", "cortez", "jhayco", "enérgico")),3));
        save(new Beat("CUANDO SERA", GENERO.REGGAETON, "Beat de reggaeton tipo Feid y Jhay Cortez", "hTXIAHgKgew", 15.99, new HashSet<>(Arrays.asList("jhay","ferxxo", "cortez", "jhayco", "feid", "jhay", "reggaeton", "cuando", "sera", "feliz")), 3));
        save(new Beat("SATEO", GENERO.REGGAETON, "Beat de Reggaeton y Perreo tipo DEI V", "gJ63u5CvJIA", 11.99, new HashSet<>(Arrays.asList("reggaeton", "perreo", "dei", "V","sateo", "feliz", "energico")), 3));
        save(new Beat("HACE TIEMPO", GENERO.REGGAETON, "Beat de reggaeton tipo Feid y Mora", "SgpY2dspMyY", 9.49, new HashSet<>(Arrays.asList("feid", "ferxxo", "mora", "reggaeton","tiempo", "feliz", "energico")), 3));
        // POP
        save(new Beat("PORQUE SIN TI", GENERO.POP, "Beat de POP urbano", "9g2W9eviPBs", 10.99, new HashSet<>(Arrays.asList("pop", "PORQUE", "SIN", "TI","urbano")), 3));
        save(new Beat("VITAMIN", GENERO.POP, "Beat de POP urbano tipo POST MALONE", "AXHgacpaFyE", 16.99, new HashSet<>(Arrays.asList("pop", "urbano", "malone", "post","vitamin")), 3));
        save(new Beat("LOVERS", GENERO.POP, "Beat de POP romantico tipo IANN DIOR", "OGNWyPy_4wc", 10.99, new HashSet<>(Arrays.asList("pop", "amor", "lovers", "dior","iann", "feliz", "enamorado")), 3));
        save(new Beat("PORQUE SIN TI", GENERO.POP, "Beat de POP urbano", "9g2W9eviPBs", 10.99, new HashSet<>(Arrays.asList("pop", "PORQUE", "SIN", "TI","PORQUE SIN TI")), 3));
        // HIP HOP
        save(new Beat("PORQUE SIN TI", GENERO.HIP_HOP, "Beat de POP urbano", "9g2W9eviPBs", 10.99, new HashSet<>(Arrays.asList("pop", "PORQUE", "SIN", "TI","PORQUE SIN TI")), 3));
        save(new Beat("PORQUE SIN TI", GENERO.HIP_HOP, "Beat de POP urbano", "9g2W9eviPBs", 10.99, new HashSet<>(Arrays.asList("pop", "PORQUE", "SIN", "TI","PORQUE SIN TI")), 3));
        save(new Beat("PORQUE SIN TI", GENERO.HIP_HOP, "Beat de POP urbano", "9g2W9eviPBs", 10.99, new HashSet<>(Arrays.asList("pop", "PORQUE", "SIN", "TI","PORQUE SIN TI")), 3));
        save(new Beat("PORQUE SIN TI", GENERO.HIP_HOP, "Beat de POP urbano", "9g2W9eviPBs", 10.99, new HashSet<>(Arrays.asList("pop", "PORQUE", "SIN", "TI","PORQUE SIN TI")), 3));
        // RAP
        save(new Beat("PORQUE SIN TI", GENERO.RAP, "Beat de POP urbano", "9g2W9eviPBs", 10.99, new HashSet<>(Arrays.asList("pop", "PORQUE", "SIN", "TI","PORQUE SIN TI")), 3));
        save(new Beat("PORQUE SIN TI", GENERO.RAP, "Beat de POP urbano", "9g2W9eviPBs", 10.99, new HashSet<>(Arrays.asList("pop", "PORQUE", "SIN", "TI","PORQUE SIN TI")), 3));
        save(new Beat("PORQUE SIN TI", GENERO.RAP, "Beat de POP urbano", "9g2W9eviPBs", 10.99, new HashSet<>(Arrays.asList("pop", "PORQUE", "SIN", "TI","PORQUE SIN TI")), 3));
        save(new Beat("PORQUE SIN TI", GENERO.RAP, "Beat de POP urbano", "9g2W9eviPBs", 10.99, new HashSet<>(Arrays.asList("pop", "PORQUE", "SIN", "TI","PORQUE SIN TI")), 3));
        // RB
        save(new Beat("PORQUE SIN TI", GENERO.RB, "Beat de POP urbano", "9g2W9eviPBs", 10.99, new HashSet<>(Arrays.asList("pop", "PORQUE", "SIN", "TI","PORQUE SIN TI")), 3));
        save(new Beat("PORQUE SIN TI", GENERO.RB, "Beat de POP urbano", "9g2W9eviPBs", 10.99, new HashSet<>(Arrays.asList("pop", "PORQUE", "SIN", "TI","PORQUE SIN TI")), 3));
        save(new Beat("PORQUE SIN TI", GENERO.RB, "Beat de POP urbano", "9g2W9eviPBs", 10.99, new HashSet<>(Arrays.asList("pop", "PORQUE", "SIN", "TI","PORQUE SIN TI")), 3));
        save(new Beat("PORQUE SIN TI", GENERO.RB, "Beat de POP urbano", "9g2W9eviPBs", 10.99, new HashSet<>(Arrays.asList("pop", "PORQUE", "SIN", "TI","PORQUE SIN TI")), 3));
        // ELECTRONICA
        save(new Beat("PORQUE SIN TI", GENERO.ELECTRONICA, "Beat de POP urbano", "9g2W9eviPBs", 10.99, new HashSet<>(Arrays.asList("pop", "PORQUE", "SIN", "TI","PORQUE SIN TI")), 3));
        save(new Beat("PORQUE SIN TI", GENERO.ELECTRONICA, "Beat de POP urbano", "9g2W9eviPBs", 10.99, new HashSet<>(Arrays.asList("pop", "PORQUE", "SIN", "TI","PORQUE SIN TI")), 3));
        save(new Beat("PORQUE SIN TI", GENERO.ELECTRONICA, "Beat de POP urbano", "9g2W9eviPBs", 10.99, new HashSet<>(Arrays.asList("pop", "PORQUE", "SIN", "TI","PORQUE SIN TI")), 3));
        save(new Beat("PORQUE SIN TI", GENERO.ELECTRONICA, "Beat de POP urbano", "9g2W9eviPBs", 10.99, new HashSet<>(Arrays.asList("pop", "PORQUE", "SIN", "TI","PORQUE SIN TI")), 3));
    }   
    public void save(Beat beat){
        if (beat.getId() == null || beat.getId()==0){
            long id = nextId.getAndIncrement();
            beat.setId(id);
        }
        beats.put(beat.getId(), beat);
    }
    public Collection<Beat> findAll(){
        return beats.values();
    }
    public Beat findById(Long id){
        return beats.get(id);
    }
    public void deleteById(Long id){
        beats.remove(id);
    }
}
